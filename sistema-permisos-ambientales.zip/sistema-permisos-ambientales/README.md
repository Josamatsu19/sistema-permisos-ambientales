# Sistema de Permisos Ambientales

Sistema web desarrollado para gestionar permisos y solicitudes ambientales.

El proyecto utiliza una arquitectura separada entre frontend, backend y base de datos. Durante el Sprint 1 se implementó el módulo de autenticación de usuarios, incluyendo registro, inicio de sesión, cifrado de contraseñas, autenticación mediante JWT y protección de rutas.

---

# 1. Tecnologías utilizadas

## Backend

- Node.js
- Express.js
- MySQL2
- bcrypt
- JSON Web Token (JWT)
- dotenv

## Frontend

- HTML5
- CSS3
- JavaScript
- Fetch API
- LocalStorage

## Base de datos

- MySQL
- XAMPP
- phpMyAdmin

## Herramientas

- Visual Studio Code
- Postman
- Git
- Jenkins (pendiente de configuración)

---

# 2. Estado actual del proyecto

## Sprint 1 - Autenticación

### Registro de usuarios

Implementado:

- Formulario de registro.
- Registro desde el frontend.
- API REST para registrar usuarios.
- Validación de campos obligatorios.
- Validación de correo duplicado.
- Contraseñas protegidas mediante bcrypt.
- Almacenamiento del usuario en MySQL.

### Inicio de sesión

Implementado:

- Formulario de inicio de sesión.
- Validación de correo y contraseña.
- Comparación de contraseña mediante bcrypt.
- Generación de JWT.
- Middleware para validar JWT.
- Ruta protegida.
- Dashboard protegido.
- Cierre de sesión.
- Expiración del token configurada en 1 hora.

### Jenkins

Pendiente de configuración.

Esta sección será actualizada después de realizar la configuración inicial de Jenkins.

---

# 3. Estructura del proyecto

```text
sistema-permisos-ambientales/
│
├── backend/
│   │
│   ├── config/
│   │   └── database.js
│   │
│   ├── controllers/
│   │   └── authController.js
│   │
│   ├── middleware/
│   │   └── authMiddleware.js
│   │
│   ├── routes/
│   │   └── authRoutes.js
│   │
│   ├── node_modules/
│   │
│   ├── .env
│   ├── package.json
│   ├── package-lock.json
│   └── server.js
│
├── frontend/
│   │
│   ├── css/
│   │   └── styles.css
│   │
│   ├── js/
│   │   ├── dashboard.js
│   │   ├── login.js
│   │   └── registro.js
│   │
│   ├── dashboard.html
│   ├── login.html
│   └── registro.html
│
├── .env.example
├── .gitignore
└── README.md
```

> `node_modules` y `.env` existen localmente, pero no deben almacenarse en Git.

---

# 4. Descripción de los archivos principales

## backend/server.js

Es el punto de entrada del backend.

Se encarga de:

- Crear el servidor Express.
- Habilitar el procesamiento de JSON.
- Publicar los archivos del frontend.
- Registrar las rutas de autenticación.
- Iniciar el servidor.

El servidor utiliza por defecto:

```text
http://localhost:3000
```

---

## backend/config/database.js

Contiene la configuración de conexión con MySQL.

Los datos de conexión se obtienen mediante variables de entorno.

---

## backend/controllers/authController.js

Contiene la lógica relacionada con la autenticación.

Actualmente incluye:

```text
registrar()
login()
```

### registrar()

Se encarga de:

1. Recibir nombre, apellido, correo y contraseña.
2. Validar los campos.
3. Comprobar si el correo ya existe.
4. Generar un hash de la contraseña mediante bcrypt.
5. Registrar el usuario en MySQL.

### login()

Se encarga de:

1. Recibir correo y contraseña.
2. Buscar el usuario.
3. Comparar la contraseña mediante bcrypt.
4. Generar un JWT si las credenciales son correctas.
5. Devolver los datos básicos del usuario y el token.

---

## backend/routes/authRoutes.js

Define las rutas relacionadas con autenticación.

Actualmente existen:

```text
POST /api/auth/register
POST /api/auth/login
GET  /api/auth/perfil
```

---

## backend/middleware/authMiddleware.js

Middleware encargado de proteger rutas.

Busca un JWT mediante el encabezado:

```text
Authorization: Bearer TOKEN
```

Posteriormente utiliza:

```javascript
jwt.verify()
```

para comprobar que el token sea válido.

Si el token es correcto, permite continuar con:

```javascript
next();
```

Si no existe, es incorrecto o expiró, responde con `401 Unauthorized`.

---

# 5. Requisitos previos

Para ejecutar el proyecto se necesita:

- Node.js
- npm
- XAMPP
- MySQL
- phpMyAdmin
- Git

Postman es recomendado para realizar pruebas de la API.

Para verificar Node.js:

```bash
node --version
```

Para verificar npm:

```bash
npm --version
```

Para verificar Git:

```bash
git --version
```

---

# 6. Instalación del proyecto

Después de obtener el repositorio, entrar al backend:

```bash
cd sistema-permisos-ambientales/backend
```

Instalar las dependencias:

```bash
npm install
```

No es necesario compartir la carpeta `node_modules`.

`npm install` reconstruirá las dependencias utilizando `package.json` y `package-lock.json`.

---

# 7. Configuración de variables de entorno

El archivo:

```text
backend/.env
```

no debe almacenarse en Git.

En la raíz existe:

```text
.env.example
```

como referencia.

Crear `backend/.env` con:

```env
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=
DB_NAME=sistema_permisos_ambientales
PORT=3000

JWT_SECRET=colocar_una_clave_secreta
```

Cada desarrollador debe utilizar su propia configuración.

Nunca publicar el valor real de:

```text
JWT_SECRET
```

---

# 8. Base de datos

El proyecto utiliza MySQL.

Antes de ejecutar el backend:

1. Iniciar XAMPP.
2. Iniciar MySQL.
3. Abrir phpMyAdmin.
4. Crear la base de datos correspondiente.
5. Crear la tabla `usuarios`.

Base de datos utilizada actualmente:

```text
sistema_permisos_ambientales
```

## Tabla usuarios

La aplicación actualmente requiere los siguientes datos:

```text
id
nombre
apellido
correo
password_hash
rol
fecha_creacion
```

Ejemplo de estructura:

```sql
CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    apellido VARCHAR(100) NOT NULL,
    correo VARCHAR(150) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    rol VARCHAR(50) DEFAULT 'usuario',
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

Las contraseñas NO se almacenan directamente.

Ejemplo:

```text
Contraseña escrita:
Prueba123

Base de datos:
$2b$10$...
```

El hash se genera mediante bcrypt.

---

# 9. Ejecutar el proyecto

Primero iniciar MySQL desde XAMPP.

Después abrir una terminal:

```bash
cd backend
```

Ejecutar:

```bash
node server.js
```

Si todo está correctamente configurado debe aparecer:

```text
Servidor ejecutándose en el puerto 3000
Conexión con MySQL exitosa
```

---

# 10. Acceso al frontend

## Registro

```text
http://localhost:3000/registro.html
```

## Inicio de sesión

```text
http://localhost:3000/login.html
```

## Dashboard

```text
http://localhost:3000/dashboard.html
```

El dashboard requiere una autenticación válida.

---

# 11. API actual

## Registrar usuario

```http
POST /api/auth/register
```

Body:

```json
{
    "nombre": "Juan",
    "apellido": "Vasquez",
    "correo": "usuario@ejemplo.com",
    "password": "Prueba123"
}
```

Registro exitoso:

```text
201 Created
```

Ejemplo:

```json
{
    "mensaje": "Usuario registrado correctamente",
    "usuarioId": 1
}
```

---

## Iniciar sesión

```http
POST /api/auth/login
```

Body:

```json
{
    "correo": "usuario@ejemplo.com",
    "password": "Prueba123"
}
```

Respuesta exitosa:

```text
200 OK
```

La respuesta contiene:

```json
{
    "mensaje": "Inicio de sesión exitoso",
    "token": "JWT_GENERADO",
    "usuario": {
        "id": 1,
        "nombre": "Juan",
        "apellido": "Vasquez",
        "correo": "usuario@ejemplo.com",
        "rol": "usuario"
    }
}
```

---

## Consultar perfil protegido

```http
GET /api/auth/perfil
```

Requiere:

```text
Authorization: Bearer TOKEN
```

Sin token:

```text
401 Unauthorized
```

Con un token válido:

```text
200 OK
```

---

# 12. Flujo de autenticación

```text
Usuario
   │
   ▼
login.html
   │
   ▼
login.js
   │
   │ POST /api/auth/login
   ▼
authRoutes.js
   │
   ▼
authController.js
   │
   ├── Busca usuario en MySQL
   │
   ├── bcrypt.compare()
   │
   ▼
Credenciales correctas
   │
   ▼
jwt.sign()
   │
   ▼
JWT
   │
   ▼
Frontend
   │
   ├── Guarda token
   ▼
dashboard.html
   │
   │ GET /api/auth/perfil
   │ Authorization: Bearer TOKEN
   ▼
authMiddleware.js
   │
   ├── jwt.verify()
   │
   ▼
Acceso autorizado
```

---

# 13. Cierre de sesión

Actualmente el JWT se almacena en `localStorage`.

Al cerrar sesión se eliminan:

```text
token
usuario
```

y el usuario es redirigido a:

```text
login.html
```

Si intenta acceder al dashboard sin un token válido, es enviado nuevamente al login.

---

# 14. Pruebas realizadas

Durante el Sprint 1 se realizaron pruebas utilizando Postman y el frontend.

| Prueba | Resultado esperado |
|---|---|
| Registro correcto | 201 Created |
| Correo duplicado | 409 Conflict |
| Campos incompletos | 400 Bad Request |
| Login correcto | 200 OK |
| Contraseña incorrecta | 401 Unauthorized |
| Usuario inexistente | 401 Unauthorized |
| Perfil sin JWT | 401 Unauthorized |
| Perfil con JWT válido | 200 OK |
| Cerrar sesión | Regresa al login |
| Acceder al dashboard sin sesión | Regresa al login |

---

# 15. Seguridad implementada

Actualmente se implementaron las siguientes medidas:

### bcrypt

Las contraseñas son transformadas en hashes antes de almacenarlas.

```javascript
bcrypt.hash()
```

Para iniciar sesión:

```javascript
bcrypt.compare()
```

---

### JWT

Después de iniciar sesión correctamente se genera un JSON Web Token.

Actualmente expira después de:

```text
1 hora
```

---

### Consultas parametrizadas

Las consultas MySQL utilizan parámetros:

```javascript
WHERE correo = ?
```

Esto evita concatenar directamente los datos recibidos dentro de las consultas SQL.

---

### Variables de entorno

La configuración sensible se mantiene en:

```text
backend/.env
```

Este archivo está excluido mediante `.gitignore`.

---

# 16. Git

Los siguientes archivos o carpetas NO deben almacenarse en el repositorio:

```text
backend/node_modules/
backend/.env
*.log
.vscode/
```

Estos valores se encuentran configurados en:

```text
.gitignore
```

Antes de realizar un commit se recomienda ejecutar:

```bash
git status
```

y comprobar que `.env` no aparezca entre los archivos que se subirán.

---

# 17. Sprint 2 - Solicitudes

El siguiente Sprint incorpora el módulo de solicitudes.

## Requerimientos

### 1. Creación de solicitudes

El usuario autenticado deberá poder crear una solicitud.

Se recomienda crear:

```text
backend/controllers/solicitudController.js
backend/routes/solicitudRoutes.js
```

La ruta deberá utilizar:

```text
authMiddleware.js
```

para identificar al usuario autenticado.

Flujo propuesto:

```text
Usuario autenticado
       │
       ▼
Formulario solicitud
       │
       ▼
POST /api/solicitudes
       │
       ▼
authMiddleware
       │
       ▼
solicitudController
       │
       ▼
MySQL
```

La solicitud debería quedar asociada al `id` del usuario autenticado.

---

### 2. Edición de solicitudes

Se deberá permitir modificar solicitudes existentes.

Posible endpoint:

```http
PUT /api/solicitudes/:id
```

Antes de modificar una solicitud se debe validar:

- Que exista.
- Que el usuario esté autenticado.
- Que tenga autorización para modificarla.
- Que la solicitud se encuentre en un estado que permita edición.

No confiar en un `usuario_id` enviado directamente desde el frontend.

El usuario debe obtenerse desde el JWT validado.

---

### 3. Automatización de pruebas API

Actualmente las pruebas se realizaron manualmente mediante Postman.

Durante Sprint 2 deberán automatizarse las pruebas de API.

Como mínimo deberían existir pruebas para:

```text
Registro
Login
Acceso protegido
Crear solicitud
Editar solicitud
Intentar acceder sin token
Intentar modificar una solicitud sin autorización
```

La herramienta específica deberá definirse durante el Sprint 2.

---

# 18. Sprint 3 - Documentación

## 1. Gestión de documentos

Se deberá permitir asociar documentos a las solicitudes.

Antes de implementar esta funcionalidad se debe definir:

- Tipos de documentos permitidos.
- Tamaño máximo.
- Ubicación de almacenamiento.
- Relación entre documento y solicitud.
- Validación de extensiones.
- Control de acceso.
- Nombre generado para los archivos.

No almacenar archivos recibidos utilizando directamente el nombre enviado por el usuario sin validación.

---

## 2. Consulta de estado de solicitudes

Los usuarios deberán poder consultar el estado de sus solicitudes.

Ejemplos de estados que podrían evaluarse durante el Sprint:

```text
Pendiente
En revisión
Aprobada
Rechazada
```

Los estados definitivos deberán establecerse según los requisitos funcionales del proyecto.

Posible endpoint:

```http
GET /api/solicitudes/:id
```

La consulta deberá comprobar que el usuario tenga autorización para acceder a la solicitud.

---

# 19. Consideraciones para continuar el proyecto

Antes de comenzar un nuevo módulo:

1. Actualizar el repositorio.
2. Ejecutar `npm install`.
3. Crear `.env` utilizando `.env.example`.
4. Iniciar MySQL.
5. Comprobar el login.
6. Comprobar `/api/auth/perfil`.
7. Crear las nuevas rutas.
8. Proteger las rutas necesarias mediante `authMiddleware`.
9. Probar los endpoints.
10. Actualizar este README.

---

# 20. Jenkins

Estado actual:

```text
PENDIENTE
```

La configuración inicial de Jenkins corresponde al Sprint 1, pero todavía no se ha realizado.

Cuando se complete deberán documentarse aquí:

- Instalación de Jenkins.
- Configuración inicial.
- Plugins utilizados.
- Configuración de Node.js.
- Integración con Git.
- Creación del pipeline.
- Jenkinsfile.
- Comandos ejecutados por el pipeline.
- Evidencia de la primera ejecución exitosa.

---

# 21. Estado de los Sprints

```text
SPRINT 1
Autenticación
├── Registro                         COMPLETADO
├── Inicio de sesión                 COMPLETADO
├── bcrypt                           COMPLETADO
├── JWT                              COMPLETADO
├── Middleware de autenticación      COMPLETADO
├── Dashboard protegido              COMPLETADO
├── Cierre de sesión                 COMPLETADO
├── README                           COMPLETADO
└── Jenkins                          PENDIENTE


SPRINT 2
Solicitudes
├── Creación de solicitudes          PENDIENTE
├── Edición de solicitudes           PENDIENTE
└── Automatización pruebas API       PENDIENTE


SPRINT 3
Documentación
├── Gestión de documentos            PENDIENTE
└── Consulta estado solicitudes      PENDIENTE
```

---

# 22. Nota para desarrolladores

Después de realizar cambios importantes en la arquitectura, base de datos, endpoints, variables de entorno o configuración de Jenkins, actualizar este archivo.

El objetivo es que este README permanezca como guía principal para instalar, ejecutar, probar y continuar el desarrollo del Sistema de Permisos Ambientales.